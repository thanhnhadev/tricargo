<script src="resources/plugins/OwlCarousel2-2.3.4/dist/owl.carousel.min.js"></script>
<!-- <script src="resources/plugins/OwlCarousel2-2.3.4/docs/assets/vendors/jquery.min.js"></script> -->
<script src="resources/plugins/jquery-nice-select-1.1.0/js/jquery.nice-select.js"></script>
