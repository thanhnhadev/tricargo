<link href="public/frontend/resources/uikit/css/components/slideshow.min.css" rel="stylesheet" />
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,400;0,700;1,500&display=swap" rel="stylesheet">
