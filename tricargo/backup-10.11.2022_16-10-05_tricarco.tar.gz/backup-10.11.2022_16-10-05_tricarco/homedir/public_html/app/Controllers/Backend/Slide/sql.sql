INSERT INTO `panel_translate` (`id`,`objectid`, `language`,  `title`, `description`, `canonical`) VALUES
(1,1, 'en',  'General Information', '', 'general-information'),
(2,2, 'en',  'We Are The Leading Industrial Factory In The World','',  'welcome-to-steeler'),
(3,3, 'en',  'Our Latest Projects', 'All functions including supply chain, value chain, project scheduling, manufacturing, services and spares,\r\ntechnology, R&D, etc. are integrated to give a complete solutions package.', 'our-latest-projects'),
(4,4, 'en',  'Company', 'Our people are our biggest asset but the only way to unlock their potential is to\r\ninvest in the right business systems that encourage innovation.', 'company'),
(5,5, 'en',  'Testimonials', 'We’ve structured our workflow processes were from the funny the century rather, initial all the made, have spare to negatives.',  'testimonials'),
(6,6, 'en',  'Our Teams', ' The team has consulted on a number of new development projects in New York. They <br> offer guidance on navigating all stages of development.', 'our-teams'),
(7,7, 'en',  'What&#039;s Going On In Our Blog?', 'Contact our office for a free quote! It is always good to have a rough idea on your<br> budget at this stage to enable us to quote as necessary.', 'what-s-going-on-in-our-blog');
