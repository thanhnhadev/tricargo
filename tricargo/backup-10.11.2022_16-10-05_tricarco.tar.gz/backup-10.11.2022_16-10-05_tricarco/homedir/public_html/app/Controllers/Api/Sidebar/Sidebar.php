<?php 
namespace App\Controllers\Api\Sidebar;
use App\Controllers\BaseController;

class Sidebar extends BaseController{

	public function __construct(){
	}

	public function index(){
		
	}
}
